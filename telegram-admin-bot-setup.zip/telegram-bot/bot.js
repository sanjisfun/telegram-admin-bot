require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');

// Токен бота от @BotFather (вставлен по вашему запросу)
const TOKEN = process.env.BOT_TOKEN || '8635918990:AAGr7Wc1LAGnZcK7y-glbg12vZC9VRviHtg';

// Создаём бота
const bot = new TelegramBot(TOKEN, { polling: true });

// Хранилище данных
const warnings = new Map(); // chatId -> { oderId: count }
const chatRules = new Map(); // chatId -> rules text
const mutedUsers = new Map(); // `${chatId}_${userId}` -> timeout

console.log('🤖 Бот запущен!');

// ============ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ============

// Проверка, является ли пользователь админом
async function isAdmin(chatId, userId) {
  try {
    const member = await bot.getChatMember(chatId, userId);
    return ['administrator', 'creator'].includes(member.status);
  } catch (e) {
    return false;
  }
}

// Получить ID пользователя из ответа или упоминания
function getTargetUser(msg) {
  if (msg.reply_to_message) {
    return {
      id: msg.reply_to_message.from.id,
      name: msg.reply_to_message.from.first_name
    };
  }
  return null;
}

// Форматирование времени
function parseTime(timeStr) {
  const match = timeStr.match(/^(\d+)([mhd])$/);
  if (!match) return null;
  
  const value = parseInt(match[1]);
  const unit = match[2];
  
  const multipliers = { m: 60, h: 3600, d: 86400 };
  return value * multipliers[unit];
}

// ============ КОМАНДА /start ============
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  
  const welcomeText = `
🤖 *Привет! Я бот-администратор*

📋 *Команды администратора:*

👤 *Управление пользователями:*
/ban - Забанить пользователя
/unban - Разбанить пользователя
/kick - Кикнуть из группы
/mute \\[время\\] - Замутить (пр: /mute 1h)
/unmute - Размутить
/warn - Предупредить (3 = бан)
/unwarn - Снять предупреждение

📢 *Сообщения:*
/broadcast \\[текст\\] - Рассылка
/pin - Закрепить сообщение
/unpin - Открепить сообщение
/del - Удалить сообщение

👑 *Администраторы:*
/promote - Повысить до админа
/demote - Понизить админа
/admins - Список админов

📊 *Информация:*
/stats - Статистика чата
/rules - Показать правила
/setrules \\[текст\\] - Установить правила
/info - Информация о пользователе

💡 *Использование:* Ответьте на сообщение пользователя и введите команду
  `;
  
  await bot.sendMessage(chatId, welcomeText, { parse_mode: 'Markdown' });
});

// ============ 1. БАН ============
bot.onText(/\/ban/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  const target = getTargetUser(msg);
  if (!target) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя, которого хотите забанить');
  }
  
  if (await isAdmin(chatId, target.id)) {
    return bot.sendMessage(chatId, '❌ Нельзя забанить администратора');
  }
  
  try {
    await bot.banChatMember(chatId, target.id);
    await bot.sendMessage(chatId, `🔨 Пользователь *${target.name}* забанен`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 2. РАЗБАН ============
bot.onText(/\/unban/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  const target = getTargetUser(msg);
  if (!target) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя, которого хотите разбанить');
  }
  
  try {
    await bot.unbanChatMember(chatId, target.id, { only_if_banned: true });
    await bot.sendMessage(chatId, `✅ Пользователь *${target.name}* разбанен`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 3. КИК ============
bot.onText(/\/kick/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  const target = getTargetUser(msg);
  if (!target) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя, которого хотите кикнуть');
  }
  
  if (await isAdmin(chatId, target.id)) {
    return bot.sendMessage(chatId, '❌ Нельзя кикнуть администратора');
  }
  
  try {
    await bot.banChatMember(chatId, target.id);
    await bot.unbanChatMember(chatId, target.id); // Сразу разбаним чтобы мог вернуться
    await bot.sendMessage(chatId, `👢 Пользователь *${target.name}* кикнут`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 4. МУТ ============
bot.onText(/\/mute(?:\s+(\S+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  const timeArg = match[1] || '1h';
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  const target = getTargetUser(msg);
  if (!target) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя\nИспользование: /mute [время]\nПримеры: /mute 30m, /mute 2h, /mute 1d');
  }
  
  if (await isAdmin(chatId, target.id)) {
    return bot.sendMessage(chatId, '❌ Нельзя замутить администратора');
  }
  
  const seconds = parseTime(timeArg);
  if (!seconds) {
    return bot.sendMessage(chatId, '❌ Неверный формат времени. Примеры: 30m, 2h, 1d');
  }
  
  const untilDate = Math.floor(Date.now() / 1000) + seconds;
  
  try {
    await bot.restrictChatMember(chatId, target.id, {
      permissions: {
        can_send_messages: false,
        can_send_media_messages: false,
        can_send_other_messages: false,
        can_add_web_page_previews: false
      },
      until_date: untilDate
    });
    
    const timeText = timeArg.replace('m', ' мин').replace('h', ' час').replace('d', ' дн');
    await bot.sendMessage(chatId, `🔇 Пользователь *${target.name}* замучен на ${timeText}`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 5. РАЗМУТ ============
bot.onText(/\/unmute/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  const target = getTargetUser(msg);
  if (!target) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя, которого хотите размутить');
  }
  
  try {
    await bot.restrictChatMember(chatId, target.id, {
      permissions: {
        can_send_messages: true,
        can_send_media_messages: true,
        can_send_polls: true,
        can_send_other_messages: true,
        can_add_web_page_previews: true,
        can_change_info: false,
        can_invite_users: true,
        can_pin_messages: false
      }
    });
    await bot.sendMessage(chatId, `🔊 Пользователь *${target.name}* размучен`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 6. ПРЕДУПРЕЖДЕНИЕ ============
bot.onText(/\/warn/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  const target = getTargetUser(msg);
  if (!target) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя, которого хотите предупредить');
  }
  
  if (await isAdmin(chatId, target.id)) {
    return bot.sendMessage(chatId, '❌ Нельзя предупредить администратора');
  }
  
  const key = `${chatId}`;
  if (!warnings.has(key)) {
    warnings.set(key, new Map());
  }
  
  const chatWarnings = warnings.get(key);
  const currentWarns = (chatWarnings.get(target.id) || 0) + 1;
  chatWarnings.set(target.id, currentWarns);
  
  if (currentWarns >= 3) {
    try {
      await bot.banChatMember(chatId, target.id);
      chatWarnings.delete(target.id);
      await bot.sendMessage(chatId, `🔨 Пользователь *${target.name}* получил 3 предупреждения и был забанен!`, { parse_mode: 'Markdown' });
    } catch (e) {
      await bot.sendMessage(chatId, `❌ Ошибка при бане: ${e.message}`);
    }
  } else {
    await bot.sendMessage(chatId, `⚠️ Пользователь *${target.name}* получил предупреждение (${currentWarns}/3)`, { parse_mode: 'Markdown' });
  }
});

// ============ 7. СНЯТЬ ПРЕДУПРЕЖДЕНИЕ ============
bot.onText(/\/unwarn/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  const target = getTargetUser(msg);
  if (!target) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя');
  }
  
  const key = `${chatId}`;
  if (!warnings.has(key)) {
    return bot.sendMessage(chatId, `ℹ️ У пользователя *${target.name}* нет предупреждений`, { parse_mode: 'Markdown' });
  }
  
  const chatWarnings = warnings.get(key);
  const currentWarns = chatWarnings.get(target.id) || 0;
  
  if (currentWarns === 0) {
    return bot.sendMessage(chatId, `ℹ️ У пользователя *${target.name}* нет предупреждений`, { parse_mode: 'Markdown' });
  }
  
  chatWarnings.set(target.id, currentWarns - 1);
  await bot.sendMessage(chatId, `✅ Снято предупреждение у *${target.name}* (${currentWarns - 1}/3)`, { parse_mode: 'Markdown' });
});

// ============ 8. РАССЫЛКА ============
bot.onText(/\/broadcast(?:\s+(.+))?/s, async (msg, match) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  const text = match[1];
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  if (!text) {
    return bot.sendMessage(chatId, '❌ Использование: /broadcast [текст сообщения]');
  }
  
  const broadcastText = `📢 *ОБЪЯВЛЕНИЕ*\n\n${text}`;
  
  try {
    await bot.sendMessage(chatId, broadcastText, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 9. ЗАКРЕПИТЬ ============
bot.onText(/\/pin/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение, которое хотите закрепить');
  }
  
  try {
    await bot.pinChatMessage(chatId, msg.reply_to_message.message_id);
    await bot.sendMessage(chatId, '📌 Сообщение закреплено');
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 10. ОТКРЕПИТЬ ============
bot.onText(/\/unpin/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  try {
    await bot.unpinChatMessage(chatId);
    await bot.sendMessage(chatId, '📌 Сообщение откреплено');
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 11. УДАЛИТЬ СООБЩЕНИЕ ============
bot.onText(/\/del/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение, которое хотите удалить');
  }
  
  try {
    await bot.deleteMessage(chatId, msg.reply_to_message.message_id);
    await bot.deleteMessage(chatId, msg.message_id); // Удаляем и команду
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 12. ПОВЫСИТЬ ДО АДМИНА ============
bot.onText(/\/promote/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  const target = getTargetUser(msg);
  if (!target) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя, которого хотите повысить');
  }
  
  try {
    await bot.promoteChatMember(chatId, target.id, {
      can_delete_messages: true,
      can_restrict_members: true,
      can_pin_messages: true,
      can_invite_users: true,
      can_manage_chat: true
    });
    await bot.sendMessage(chatId, `👑 Пользователь *${target.name}* повышен до администратора`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 13. ПОНИЗИТЬ АДМИНА ============
bot.onText(/\/demote/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  const target = getTargetUser(msg);
  if (!target) {
    return bot.sendMessage(chatId, '❌ Ответьте на сообщение администратора, которого хотите понизить');
  }
  
  try {
    await bot.promoteChatMember(chatId, target.id, {
      can_delete_messages: false,
      can_restrict_members: false,
      can_pin_messages: false,
      can_invite_users: false,
      can_manage_chat: false,
      can_change_info: false,
      can_promote_members: false
    });
    await bot.sendMessage(chatId, `📉 Пользователь *${target.name}* понижен`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 14. СПИСОК АДМИНОВ ============
bot.onText(/\/admins/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  try {
    const admins = await bot.getChatAdministrators(chatId);
    
    let text = '👑 *Администраторы чата:*\n\n';
    
    admins.forEach((admin, index) => {
      const status = admin.status === 'creator' ? '👤 Создатель' : '⭐ Админ';
      const name = admin.user.first_name + (admin.user.last_name ? ' ' + admin.user.last_name : '');
      const username = admin.user.username ? ` (@${admin.user.username})` : '';
      text += `${index + 1}. ${status}: *${name}*${username}\n`;
    });
    
    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 15. СТАТИСТИКА ============
bot.onText(/\/stats/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  try {
    const chat = await bot.getChat(chatId);
    const admins = await bot.getChatAdministrators(chatId);
    const memberCount = await bot.getChatMemberCount(chatId);
    
    const key = `${chatId}`;
    const chatWarnings = warnings.get(key);
    const totalWarnings = chatWarnings ? Array.from(chatWarnings.values()).reduce((a, b) => a + b, 0) : 0;
    
    const text = `
📊 *Статистика чата*

📝 Название: *${chat.title}*
👥 Участников: *${memberCount}*
👑 Администраторов: *${admins.length}*
⚠️ Активных предупреждений: *${totalWarnings}*
🆔 ID чата: \`${chatId}\`
    `;
    
    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ 16. ПРАВИЛА ============
bot.onText(/\/rules/, async (msg) => {
  const chatId = msg.chat.id;
  
  const rules = chatRules.get(chatId);
  
  if (!rules) {
    return bot.sendMessage(chatId, 'ℹ️ Правила чата не установлены. Админ может установить их командой /setrules');
  }
  
  await bot.sendMessage(chatId, `📜 *Правила чата:*\n\n${rules}`, { parse_mode: 'Markdown' });
});

// ============ 17. УСТАНОВИТЬ ПРАВИЛА ============
bot.onText(/\/setrules(?:\s+(.+))?/s, async (msg, match) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  const rulesText = match[1];
  
  if (msg.chat.type === 'private') {
    return bot.sendMessage(chatId, '❌ Эта команда работает только в группах');
  }
  
  if (!await isAdmin(chatId, adminId)) {
    return bot.sendMessage(chatId, '❌ У вас нет прав администратора');
  }
  
  if (!rulesText) {
    return bot.sendMessage(chatId, '❌ Использование: /setrules [текст правил]');
  }
  
  chatRules.set(chatId, rulesText);
  await bot.sendMessage(chatId, '✅ Правила чата обновлены!');
});

// ============ 18. ИНФОРМАЦИЯ О ПОЛЬЗОВАТЕЛЕ ============
bot.onText(/\/info/, async (msg) => {
  const chatId = msg.chat.id;
  
  const target = getTargetUser(msg) || { id: msg.from.id, name: msg.from.first_name };
  
  try {
    let member = null;
    if (msg.chat.type !== 'private') {
      member = await bot.getChatMember(chatId, target.id);
    }
    
    const user = msg.reply_to_message ? msg.reply_to_message.from : msg.from;
    
    const key = `${chatId}`;
    const chatWarnings = warnings.get(key);
    const userWarnings = chatWarnings ? (chatWarnings.get(target.id) || 0) : 0;
    
    let statusText = 'Личный чат';
    if (member) {
      const statusMap = {
        'creator': '👤 Создатель',
        'administrator': '⭐ Администратор',
        'member': '👥 Участник',
        'restricted': '🔇 Ограничен',
        'left': '🚪 Покинул чат',
        'kicked': '🔨 Забанен'
      };
      statusText = statusMap[member.status] || member.status;
    }
    
    const text = `
👤 *Информация о пользователе*

📝 Имя: *${user.first_name}*${user.last_name ? ' ' + user.last_name : ''}
🆔 ID: \`${user.id}\`
👤 Username: ${user.username ? '@' + user.username : 'не указан'}
🤖 Бот: ${user.is_bot ? 'Да' : 'Нет'}
📊 Статус: ${statusText}
⚠️ Предупреждений: ${userWarnings}/3
    `;
    
    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, `❌ Ошибка: ${e.message}`);
  }
});

// ============ ОБРАБОТКА ОШИБОК ============
bot.on('polling_error', (error) => {
  console.error('Ошибка polling:', error.message);
});

bot.on('error', (error) => {
  console.error('Ошибка бота:', error.message);
});

console.log('✅ Бот готов к работе!');
console.log('📋 Команды: /start для просмотра списка команд');
