import { useState } from 'react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';

// @ts-ignore
import botJs from '../telegram-bot/bot.js?raw';
// @ts-ignore
import pkgJson from '../telegram-bot/package.json?raw';
// @ts-ignore
import readme from '../telegram-bot/README.md?raw';

const envFile = `BOT_TOKEN=8635918990:AAGr7Wc1LAGnZcK7y-glbg12vZC9VRviHtg`;

export default function App() {
  const [downloading, setDownloading] = useState(false);

  const downloadZip = async () => {
    setDownloading(true);
    try {
      const zip = new JSZip();
      
      const folder = zip.folder('telegram-bot');
      if (folder) {
        folder.file('bot.js', botJs);
        folder.file('package.json', pkgJson);
        folder.file('README.md', readme);
        folder.file('.env', envFile);
      }
      
      const content = await zip.generateAsync({ type: 'blob' });
      saveAs(content, 'telegram-bot.zip');
    } catch (err) {
      console.error('Ошибка создания архива', err);
      alert('Ошибка при скачивании');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-indigo-950 text-white flex flex-col items-center justify-center p-8">
      <div className="max-w-2xl w-full text-center space-y-8 bg-slate-800/50 p-10 rounded-3xl border border-slate-700 backdrop-blur shadow-2xl">
        <div className="text-6xl mb-4">🤖</div>
        <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
          Ваш Telegram Бот Готов!
        </h1>
        
        <p className="text-lg text-slate-300">
          Мы собрали все файлы бота с вашим токеном и исправили ошибки. Теперь вы можете скачать архив со всеми необходимыми скриптами.
        </p>

        <div className="bg-slate-900/50 p-6 rounded-2xl border border-slate-700 text-left space-y-4">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <span className="text-green-400">✅</span> Что внутри:
          </h2>
          <ul className="space-y-2 text-slate-300 ml-8 list-disc">
            <li><code className="text-blue-300">bot.js</code> - Доработанный код бота (18+ функций)</li>
            <li><code className="text-blue-300">.env</code> - Ваш токен встроен и настроен</li>
            <li><code className="text-blue-300">package.json</code> - Зависимости (node-telegram-bot-api, dotenv)</li>
            <li><code className="text-blue-300">README.md</code> - Подробная инструкция по запуску</li>
          </ul>
        </div>

        <button
          onClick={downloadZip}
          disabled={downloading}
          className="group relative inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-blue-600 font-pj rounded-xl hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-600 disabled:opacity-50 hover:scale-105 active:scale-95 w-full md:w-auto text-xl shadow-lg shadow-blue-600/30"
        >
          {downloading ? 'Сборка архива...' : '📥 Скачать telegram-bot.zip'}
        </button>

        <p className="text-sm text-slate-400 mt-6">
          После скачивания распакуйте архив, установите зависимости через <code className="bg-slate-800 px-2 py-1 rounded text-green-300">npm install</code> и запустите <code className="bg-slate-800 px-2 py-1 rounded text-green-300">npm start</code>
        </p>
      </div>
    </div>
  );
}