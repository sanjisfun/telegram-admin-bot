import { useState } from 'react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { Download, Bot, CheckCircle, Terminal, Server } from 'lucide-react';

const fileContents = {
  'package.json': `{
  "name": "telegram-admin-bot",
  "version": "1.0.0",
  "description": "Telegram Admin Bot ready for Railway",
  "main": "bot.js",
  "scripts": {
    "start": "node bot.js"
  },
  "dependencies": {
    "dotenv": "^16.4.5",
    "express": "^4.19.2",
    "node-telegram-bot-api": "^0.66.0"
  },
  "engines": {
    "node": ">=18.0.0"
  }
}`,
  'railway.json': `{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "npm start",
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 10
  }
}`,
  '.env.example': `BOT_TOKEN=8635918990:AAGr7Wc1LAGnZcK7y-glbg12vZC9VRviHtg`,
  'README.md': `# 🤖 Telegram Администратор-Бот (Railway Edition)

Этот бот полностью готов к размещению на бесплатном или платном тарифе [Railway.app](https://railway.app). Он содержит все функции администратора и не требует сложных настроек сервера!

## 🚀 Как залить на Railway

Это самый простой способ:

1. Создай аккаунт на [GitHub](https://github.com) и [Railway](https://railway.app).
2. Залей эту папку (все её файлы, включая \`package.json\`, \`bot.js\`, \`railway.json\`) в новый репозиторий на GitHub (сделай его \`Private\`).
3. Зайди в Railway -> **New Project** -> **Deploy from GitHub repo**.
4. Выбери свой репозиторий с ботом.
5. Зайди во вкладку **Variables** (Переменные) в Railway.
6. Добавь переменную (New Variable):
   - Имя: \`BOT_TOKEN\`
   - Значение: \`8635918990:AAGr7Wc1LAGnZcK7y-glbg12vZC9VRviHtg\` (твой токен)
7. Бот автоматически скомпилируется и запустится!

## ⚙️ Как это работает?
В файле \`bot.js\` добавлен мини-веб-сервер (Express). Зачем он нужен? Railway и другие облачные хостинги убивают приложения, если они не слушают порт (\`PORT\`). Express сервер отвечает "OK", давая платформе понять, что бот жив, а сам бот в это время работает через Polling телеграма.

## 💻 Запуск на ПК (для тестов)
1. Установи Node.js
2. В терминале в этой папке: \`npm install\`
3. Переименуй \`.env.example\` в \`.env\`
4. Запусти: \`npm start\`
`,
  'bot.js': `require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const express = require('express');

// Токен из переменной окружения или захардкоженный токен от @BotFather
const TOKEN = process.env.BOT_TOKEN || '8635918990:AAGr7Wc1LAGnZcK7y-glbg12vZC9VRviHtg';

// ==========================================
// 1. НАСТРОЙКА ДЛЯ RAILWAY (ВЕБ-СЕРВЕР)
// ==========================================
// Railway требует, чтобы приложение слушало порт. Иначе платформа решит,
// что оно упало, и перезапустит контейнер.
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/', (req, res) => {
  res.send('Бот активен и работает (Railway Status: OK)');
});

app.listen(PORT, () => {
  console.log(\`🌐 HTTP-Сервер запущен на порту \${PORT} (Railway healthcheck)\`);
});

// ==========================================
// 2. ИНИЦИАЛИЗАЦИЯ БОТА TELEGRAM
// ==========================================
const bot = new TelegramBot(TOKEN, { polling: true });

// Хранилища данных в памяти
const warnings = new Map(); // chatId -> { userId: count }
const chatRules = new Map(); // chatId -> text

console.log('🤖 Бот Telegram запущен и подключен!');

// ============ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ============

async function isAdmin(chatId, userId) {
  try {
    const member = await bot.getChatMember(chatId, userId);
    return ['administrator', 'creator'].includes(member.status);
  } catch (e) {
    return false;
  }
}

function getTargetUser(msg) {
  if (msg.reply_to_message) {
    return {
      id: msg.reply_to_message.from.id,
      name: msg.reply_to_message.from.first_name || 'Пользователь'
    };
  }
  return null;
}

function parseTime(timeStr) {
  const match = timeStr.match(/^(\\d+)([mhd])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  const multipliers = { m: 60, h: 3600, d: 86400 };
  return value * multipliers[unit];
}

// ============ КОМАНДА /start ============
bot.onText(/\\/start/, async (msg) => {
  const chatId = msg.chat.id;
  
  const welcomeText = \`
🤖 *Привет! Я твой бот-администратор*

📋 *Команды администратора:*

👤 *Пользователи:*
/ban - Забанить
/unban - Разбанить
/kick - Кикнуть
/mute \\\\[время\\\\] - Замутить (напр: /mute 1h)
/unmute - Размутить
/warn - Предупредить (3 = бан)
/unwarn - Снять пред

📢 *Сообщения:*
/broadcast \\\\[текст\\\\] - Рассылка всем
/pin - Закрепить
/unpin - Открепить
/del - Удалить (работает реплаем)

👑 *Администраторы:*
/promote - Дать админку
/demote - Снять админку
/admins - Список админов

📊 *Информация:*
/stats - Статистика чата
/rules - Показать правила
/setrules \\\\[текст\\\\] - Задать правила
/info - Информация об участнике
  \`;
  await bot.sendMessage(chatId, welcomeText, { parse_mode: 'Markdown' });
});

// ============ 1. БАН ============
bot.onText(/\\/ban/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  if (!await isAdmin(chatId, adminId)) return bot.sendMessage(chatId, '❌ Нет прав администратора!');
  
  const target = getTargetUser(msg);
  if (!target) return bot.sendMessage(chatId, '❌ Ответьте на сообщение нарушителя.');
  if (await isAdmin(chatId, target.id)) return bot.sendMessage(chatId, '❌ Нельзя забанить администратора.');
  
  try {
    await bot.banChatMember(chatId, target.id);
    await bot.sendMessage(chatId, \`🔨 Пользователь *\${target.name}* забанен!\`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Дайте боту права на блокировку пользователей!\`);
  }
});

// ============ 2. РАЗБАН ============
bot.onText(/\\/unban/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  if (!await isAdmin(chatId, adminId)) return bot.sendMessage(chatId, '❌ Нет прав администратора!');
  
  const target = getTargetUser(msg);
  if (!target) return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя.');
  
  try {
    await bot.unbanChatMember(chatId, target.id, { only_if_banned: true });
    await bot.sendMessage(chatId, \`✅ Пользователь *\${target.name}* разбанен.\`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Недостаточно прав.\`);
  }
});

// ============ 3. КИК ============
bot.onText(/\\/kick/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  if (!await isAdmin(chatId, adminId)) return bot.sendMessage(chatId, '❌ Нет прав администратора!');
  
  const target = getTargetUser(msg);
  if (!target) return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя.');
  if (await isAdmin(chatId, target.id)) return bot.sendMessage(chatId, '❌ Нельзя кикнуть администратора.');
  
  try {
    await bot.banChatMember(chatId, target.id);
    await bot.unbanChatMember(chatId, target.id);
    await bot.sendMessage(chatId, \`👢 Пользователь *\${target.name}* изгнан!\`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Дайте боту права!\`);
  }
});

// ============ 4. МУТ ============
bot.onText(/\\/mute(?:\\s+(\\S+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  const timeArg = match[1] || '1h';
  
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  if (!await isAdmin(chatId, adminId)) return bot.sendMessage(chatId, '❌ Нет прав администратора!');
  
  const target = getTargetUser(msg);
  if (!target) return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя.\\nПример: /mute 30m, /mute 2h, /mute 1d');
  if (await isAdmin(chatId, target.id)) return bot.sendMessage(chatId, '❌ Нельзя замутить администратора.');
  
  const seconds = parseTime(timeArg);
  if (!seconds) return bot.sendMessage(chatId, '❌ Неверный формат времени. Примеры: 30m, 2h, 1d');
  
  const untilDate = Math.floor(Date.now() / 1000) + seconds;
  
  try {
    await bot.restrictChatMember(chatId, target.id, {
      permissions: { can_send_messages: false },
      until_date: untilDate
    });
    
    const timeText = timeArg.replace('m', ' мин').replace('h', ' час').replace('d', ' дн');
    await bot.sendMessage(chatId, \`🔇 *\${target.name}* замучен на \${timeText}\`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Дайте боту права ограничивать пользователей!\`);
  }
});

// ============ 5. РАЗМУТ ============
bot.onText(/\\/unmute/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  if (!await isAdmin(chatId, adminId)) return bot.sendMessage(chatId, '❌ Нет прав администратора!');
  
  const target = getTargetUser(msg);
  if (!target) return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя.');
  
  try {
    await bot.restrictChatMember(chatId, target.id, {
      permissions: {
        can_send_messages: true,
        can_send_media_messages: true,
        can_send_polls: true,
        can_send_other_messages: true,
        can_add_web_page_previews: true,
        can_invite_users: true
      }
    });
    await bot.sendMessage(chatId, \`🔊 *\${target.name}* размучен!\`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Дайте боту права ограничивать пользователей!\`);
  }
});

// ============ 6. ВАРН ============
bot.onText(/\\/warn/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  if (!await isAdmin(chatId, adminId)) return bot.sendMessage(chatId, '❌ Нет прав!');
  
  const target = getTargetUser(msg);
  if (!target) return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя.');
  if (await isAdmin(chatId, target.id)) return bot.sendMessage(chatId, '❌ Нельзя выдать варн администратору.');
  
  const key = \`\${chatId}\`;
  if (!warnings.has(key)) warnings.set(key, new Map());
  
  const chatWarnings = warnings.get(key);
  const currentWarns = (chatWarnings.get(target.id) || 0) + 1;
  chatWarnings.set(target.id, currentWarns);
  
  if (currentWarns >= 3) {
    try {
      await bot.banChatMember(chatId, target.id);
      chatWarnings.delete(target.id);
      await bot.sendMessage(chatId, \`🔨 *\${target.name}* получил 3/3 предупреждений и был забанен!\`, { parse_mode: 'Markdown' });
    } catch (e) {
      await bot.sendMessage(chatId, \`❌ Ошибка при бане: Дайте боту права.\`);
    }
  } else {
    await bot.sendMessage(chatId, \`⚠️ *\${target.name}* получил предупреждение (\${currentWarns}/3)\`, { parse_mode: 'Markdown' });
  }
});

// ============ 7. СНЯТЬ ВАРН ============
bot.onText(/\\/unwarn/, async (msg) => {
  const chatId = msg.chat.id;
  const adminId = msg.from.id;
  
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  if (!await isAdmin(chatId, adminId)) return bot.sendMessage(chatId, '❌ Нет прав!');
  
  const target = getTargetUser(msg);
  if (!target) return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя.');
  
  const key = \`\${chatId}\`;
  if (!warnings.has(key)) return bot.sendMessage(chatId, \`ℹ️ У *\${target.name}* нет предупреждений\`, { parse_mode: 'Markdown' });
  
  const chatWarnings = warnings.get(key);
  const currentWarns = chatWarnings.get(target.id) || 0;
  
  if (currentWarns === 0) return bot.sendMessage(chatId, \`ℹ️ У *\${target.name}* нет предупреждений\`, { parse_mode: 'Markdown' });
  
  chatWarnings.set(target.id, currentWarns - 1);
  await bot.sendMessage(chatId, \`✅ Снято предупреждение у *\${target.name}* (\${currentWarns - 1}/3)\`, { parse_mode: 'Markdown' });
});

// ============ 8. РАССЫЛКА ============
bot.onText(/\\/broadcast(?:\\s+(.+))?/s, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  
  if (!await isAdmin(chatId, msg.from.id)) return bot.sendMessage(chatId, '❌ Нет прав!');
  if (!text) return bot.sendMessage(chatId, '❌ Использование: /broadcast [текст сообщения]');
  
  try {
    await bot.sendMessage(chatId, \`📢 *ОБЪЯВЛЕНИЕ*\\n\\n\${text}\`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: \${e.message}\`);
  }
});

// ============ 9. ПИН (ЗАКРЕПИТЬ) ============
bot.onText(/\\/pin/, async (msg) => {
  const chatId = msg.chat.id;
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  if (!await isAdmin(chatId, msg.from.id)) return bot.sendMessage(chatId, '❌ Нет прав!');
  if (!msg.reply_to_message) return bot.sendMessage(chatId, '❌ Ответьте на сообщение, которое хотите закрепить!');
  
  try {
    await bot.pinChatMessage(chatId, msg.reply_to_message.message_id);
    await bot.sendMessage(chatId, '📌 Закреплено!');
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Дайте права на закрепление сообщений.\`);
  }
});

// ============ 10. АНПИН (ОТКРЕПИТЬ) ============
bot.onText(/\\/unpin/, async (msg) => {
  const chatId = msg.chat.id;
  if (!await isAdmin(chatId, msg.from.id)) return bot.sendMessage(chatId, '❌ Нет прав!');
  try {
    await bot.unpinChatMessage(chatId);
    await bot.sendMessage(chatId, '📌 Откреплено!');
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Дайте права.\`);
  }
});

// ============ 11. УДАЛИТЬ ============
bot.onText(/\\/del/, async (msg) => {
  const chatId = msg.chat.id;
  if (!await isAdmin(chatId, msg.from.id)) return bot.sendMessage(chatId, '❌ Нет прав!');
  if (!msg.reply_to_message) return bot.sendMessage(chatId, '❌ Ответьте на сообщение!');
  
  try {
    await bot.deleteMessage(chatId, msg.reply_to_message.message_id);
    await bot.deleteMessage(chatId, msg.message_id);
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Дайте боту права удалять сообщения.\`);
  }
});

// ============ 12. ПОВЫСИТЬ ============
bot.onText(/\\/promote/, async (msg) => {
  const chatId = msg.chat.id;
  if (!await isAdmin(chatId, msg.from.id)) return bot.sendMessage(chatId, '❌ Нет прав!');
  const target = getTargetUser(msg);
  if (!target) return bot.sendMessage(chatId, '❌ Ответьте на сообщение пользователя.');
  
  try {
    await bot.promoteChatMember(chatId, target.id, {
      can_delete_messages: true,
      can_restrict_members: true,
      can_pin_messages: true,
      can_invite_users: true,
      can_manage_chat: true
    });
    await bot.sendMessage(chatId, \`👑 *\${target.name}* назначен администратором!\`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Бот должен быть админом с правом добавлять админов.\`);
  }
});

// ============ 13. ПОНИЗИТЬ ============
bot.onText(/\\/demote/, async (msg) => {
  const chatId = msg.chat.id;
  if (!await isAdmin(chatId, msg.from.id)) return bot.sendMessage(chatId, '❌ Нет прав!');
  const target = getTargetUser(msg);
  if (!target) return bot.sendMessage(chatId, '❌ Ответьте на сообщение администратора.');
  
  try {
    await bot.promoteChatMember(chatId, target.id, {
      can_delete_messages: false,
      can_restrict_members: false,
      can_pin_messages: false,
      can_invite_users: false,
      can_manage_chat: false,
      can_change_info: false,
      can_promote_members: false
    });
    await bot.sendMessage(chatId, \`📉 *\${target.name}* лишен прав администратора!\`, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: Бот не может снять админа.\`);
  }
});

// ============ 14. СПИСОК АДМИНОВ ============
bot.onText(/\\/admins/, async (msg) => {
  const chatId = msg.chat.id;
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  
  try {
    const admins = await bot.getChatAdministrators(chatId);
    let text = '👑 *Администраторы:*\\n\\n';
    admins.forEach((admin, i) => {
      const status = admin.status === 'creator' ? '👤 Создатель' : '⭐ Админ';
      const name = admin.user.first_name + (admin.user.last_name ? ' ' + admin.user.last_name : '');
      const username = admin.user.username ? \` (@\${admin.user.username})\` : '';
      text += \`\${i + 1}. \${status}: *\${name}*\${username}\\n\`;
    });
    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: \${e.message}\`);
  }
});

// ============ 15. ПРАВИЛА ============
bot.onText(/\\/rules/, async (msg) => {
  const chatId = msg.chat.id;
  const rules = chatRules.get(chatId);
  if (!rules) return bot.sendMessage(chatId, 'ℹ️ Правила не установлены (админ может задать их через /setrules)');
  await bot.sendMessage(chatId, \`📜 *Правила чата:*\\n\\n\${rules}\`, { parse_mode: 'Markdown' });
});

bot.onText(/\\/setrules(?:\\s+(.+))?/s, async (msg, match) => {
  const chatId = msg.chat.id;
  const rulesText = match[1];
  if (!await isAdmin(chatId, msg.from.id)) return bot.sendMessage(chatId, '❌ Нет прав!');
  if (!rulesText) return bot.sendMessage(chatId, '❌ Использование: /setrules [текст правил]');
  
  chatRules.set(chatId, rulesText);
  await bot.sendMessage(chatId, '✅ Правила чата обновлены!');
});

// ============ 16. СТАТИСТИКА ============
bot.onText(/\\/stats/, async (msg) => {
  const chatId = msg.chat.id;
  if (msg.chat.type === 'private') return bot.sendMessage(chatId, '❌ Только для групп!');
  
  try {
    const chat = await bot.getChat(chatId);
    const admins = await bot.getChatAdministrators(chatId);
    const memberCount = await bot.getChatMemberCount(chatId);
    const text = \`
📊 *Статистика чата*
📝 Название: *\${chat.title}*
👥 Участников: *\${memberCount}*
👑 Админов: *\${admins.length}*
🆔 ID: \\\`\${chatId}\\\`
    \`;
    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (e) {
    await bot.sendMessage(chatId, \`❌ Ошибка: \${e.message}\`);
  }
});

// ============ 17. ИНФО О ПОЛЬЗОВАТЕЛЕ ============
bot.onText(/\\/info/, async (msg) => {
  const chatId = msg.chat.id;
  const target = getTargetUser(msg) || { id: msg.from.id, name: msg.from.first_name };
  const user = msg.reply_to_message ? msg.reply_to_message.from : msg.from;
  
  const text = \`
👤 *Информация*
📝 Имя: *\${user.first_name}*\${user.last_name ? ' ' + user.last_name : ''}
🆔 ID: \\\`\${user.id}\\\`
👤 Username: \${user.username ? '@' + user.username : 'нет'}
🤖 Бот: \${user.is_bot ? 'Да' : 'Нет'}
  \`;
  await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
});

// ============ ОБРАБОТКА ОШИБОК ============
bot.on('polling_error', (error) => console.error('Polling error:', error.message));
bot.on('error', (error) => console.error('Bot error:', error.message));
`
};

export default function App() {
  const [downloading, setDownloading] = useState(false);

  const downloadZip = async () => {
    setDownloading(true);
    try {
      const zip = new JSZip();
      
      // Add all files to the ZIP
      Object.entries(fileContents).forEach(([filename, content]) => {
        zip.file(filename, content);
      });
      
      // Generate and trigger download
      const content = await zip.generateAsync({ type: 'blob' });
      saveAs(content, 'railway-telegram-bot.zip');
    } catch (error) {
      console.error('Failed to create ZIP', error);
      alert('Ошибка при создании архива');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex items-center justify-center p-4">
      <div className="max-w-xl w-full bg-gray-800 rounded-2xl shadow-2xl overflow-hidden border border-gray-700">
        <div className="bg-blue-600 p-6 flex flex-col items-center justify-center text-center space-y-4">
          <div className="bg-white/20 p-4 rounded-full">
            <Bot size={48} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">Файлы Telegram Бота готовы!</h1>
          <p className="text-blue-100 max-w-md">
            (Railway Edition) — без лишних файлов. Внутри только Node.js скрипт, Express для healthcheck и настройки.
          </p>
        </div>

        <div className="p-8 space-y-6">
          <div className="space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <Server size={20} className="text-blue-400" /> 
              Что внутри архива?
            </h2>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-gray-300">
                <CheckCircle size={18} className="text-green-400 mt-1 flex-shrink-0" />
                <span><code className="text-blue-300 bg-blue-900/30 px-1 py-0.5 rounded">bot.js</code> — основной код с 18 командами и веб-сервером для Railway. Ваш токен уже встроен!</span>
              </li>
              <li className="flex items-start gap-3 text-gray-300">
                <CheckCircle size={18} className="text-green-400 mt-1 flex-shrink-0" />
                <span><code className="text-blue-300 bg-blue-900/30 px-1 py-0.5 rounded">package.json</code> — зависимости и скрипт запуска для платформы.</span>
              </li>
              <li className="flex items-start gap-3 text-gray-300">
                <CheckCircle size={18} className="text-green-400 mt-1 flex-shrink-0" />
                <span><code className="text-blue-300 bg-blue-900/30 px-1 py-0.5 rounded">railway.json</code> — конфиг для автоматического деплоя на серверах Railway.</span>
              </li>
              <li className="flex items-start gap-3 text-gray-300">
                <CheckCircle size={18} className="text-green-400 mt-1 flex-shrink-0" />
                <span><code className="text-blue-300 bg-blue-900/30 px-1 py-0.5 rounded">README.md</code> — подробная инструкция по заливке.</span>
              </li>
            </ul>
          </div>

          <div className="pt-4 border-t border-gray-700">
            <button
              onClick={downloadZip}
              disabled={downloading}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 px-6 rounded-xl shadow-lg transition-all duration-200 flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {downloading ? (
                <Terminal className="animate-spin" size={24} />
              ) : (
                <Download size={24} />
              )}
              {downloading ? 'Сборка архива...' : 'Скачать чистые файлы бота'}
            </button>
            <p className="text-center text-gray-500 text-sm mt-4">
              *Все лишние файлы приложения (React, Vite, CSS) удалены из архива. Вы скачаете только то, что нужно загрузить на Railway.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
