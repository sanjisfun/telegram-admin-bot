import { useState } from 'react';

const features = [
  { icon: '🔨', title: 'Бан/Разбан', desc: 'Полная блокировка пользователей', cmd: '/ban, /unban' },
  { icon: '🔇', title: 'Мут/Размут', desc: 'Временное ограничение сообщений', cmd: '/mute, /unmute' },
  { icon: '⚠️', title: 'Предупреждения', desc: 'Система warn с автобаном', cmd: '/warn, /unwarn' },
  { icon: '🗑', title: 'Очистка', desc: 'Массовое удаление сообщений', cmd: '/clear, /purge' },
  { icon: '📌', title: 'Закрепление', desc: 'Закрепление сообщений', cmd: '/pin, /unpin' },
  { icon: '👋', title: 'Приветствия', desc: 'Кастомные приветствия', cmd: '/welcome' },
  { icon: '🛡', title: 'Антиспам', desc: 'Фильтр нежелательных слов', cmd: '/antispam' },
  { icon: '🌊', title: 'Антифлуд', desc: 'Защита от флуда', cmd: '/antiflood' },
  { icon: '📊', title: 'Статистика', desc: 'Статистика чата', cmd: '/stats' },
  { icon: '🐢', title: 'Slowmode', desc: 'Медленный режим', cmd: '/slowmode' },
  { icon: '👢', title: 'Кик', desc: 'Удаление пользователя', cmd: '/kick' },
  { icon: '⚙️', title: 'Настройки', desc: 'Настройки чата', cmd: '/settings' },
];

const deployOptions = [
  {
    name: 'Railway',
    icon: '🚂',
    color: 'from-purple-500 to-indigo-600',
    free: true,
    steps: [
      'Зайдите на railway.app и войдите через GitHub',
      'Нажмите "New Project" → "Deploy from GitHub repo"',
      'Выберите ваш репозиторий с ботом',
      'В Variables добавьте: BOT_TOKEN = ваш_токен',
      'Railway автоматически запустит бота!'
    ],
    link: 'https://railway.app'
  },
  {
    name: 'Render',
    icon: '🎨',
    color: 'from-teal-500 to-cyan-600',
    free: true,
    steps: [
      'Зайдите на render.com и войдите через GitHub',
      'Нажмите "New" → "Background Worker"',
      'Подключите репозиторий',
      'Build Command: pip install -r requirements.txt',
      'Start Command: python admin_bot.py',
      'В Environment добавьте BOT_TOKEN'
    ],
    link: 'https://render.com'
  },
  {
    name: 'Fly.io',
    icon: '✈️',
    color: 'from-violet-500 to-purple-600',
    free: true,
    steps: [
      'Установите flyctl: curl -L https://fly.io/install.sh | sh',
      'fly auth login',
      'fly launch (в папке с ботом)',
      'fly secrets set BOT_TOKEN=ваш_токен',
      'fly deploy'
    ],
    link: 'https://fly.io'
  },
  {
    name: 'VPS (Свой сервер)',
    icon: '🖥️',
    color: 'from-gray-600 to-gray-800',
    free: false,
    steps: [
      'Купите VPS (DigitalOcean, Hetzner, Timeweb)',
      'SSH подключение к серверу',
      'apt update && apt install python3-pip',
      'git clone ваш_репозиторий',
      'pip install -r requirements.txt',
      'Настройте systemd для автозапуска'
    ],
    link: ''
  }
];

function App() {
  const [activeTab, setActiveTab] = useState<'features' | 'deploy' | 'code'>('features');
  const [copied, setCopied] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState(0);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const githubSteps = [
    { step: 1, title: 'Скачайте файлы', desc: 'Скачайте все файлы из папки bot/' },
    { step: 2, title: 'Создайте репозиторий', desc: 'На github.com нажмите "New repository"' },
    { step: 3, title: 'Загрузите файлы', desc: 'Загрузите файлы через "Add file" → "Upload files"' },
    { step: 4, title: 'Получите токен', desc: 'У @BotFather создайте бота командой /newbot' },
    { step: 5, title: 'Выберите хостинг', desc: 'Railway, Render или Fly.io (бесплатно!)' },
    { step: 6, title: 'Деплой!', desc: 'Следуйте инструкциям выбранного хостинга' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 backdrop-blur-xl bg-black/20">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-4xl">🤖</span>
              <div>
                <h1 className="text-2xl font-bold text-white">Telegram Admin Bot</h1>
                <p className="text-purple-300 text-sm">12 функций • Python • Aiogram 3</p>
              </div>
            </div>
            <a 
              href="/bot/admin_bot.py" 
              download
              className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg flex items-center gap-2 transition"
            >
              <span>📥</span> Скачать код
            </a>
          </div>
        </div>
      </header>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex gap-2 mb-8">
          {[
            { id: 'features', label: '✨ Функции', icon: '✨' },
            { id: 'deploy', label: '🚀 Деплой', icon: '🚀' },
            { id: 'code', label: '💻 Код', icon: '💻' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-5 py-3 rounded-xl font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/30'
                  : 'bg-white/5 text-white/70 hover:bg-white/10'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Features Tab */}
        {activeTab === 'features' && (
          <div className="space-y-8">
            <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-4">
              {features.map((f, i) => (
                <div 
                  key={i}
                  className="bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-5 hover:bg-white/10 transition group"
                >
                  <div className="text-3xl mb-3 group-hover:scale-110 transition">{f.icon}</div>
                  <h3 className="text-white font-semibold mb-1">{f.title}</h3>
                  <p className="text-white/50 text-sm mb-2">{f.desc}</p>
                  <code className="text-purple-400 text-xs bg-purple-500/10 px-2 py-1 rounded">
                    {f.cmd}
                  </code>
                </div>
              ))}
            </div>

            {/* Quick Start */}
            <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">⚡ Быстрый старт (локально)</h2>
              <div className="bg-black/40 rounded-xl p-4 font-mono text-sm">
                <div className="text-green-400">
                  <p># 1. Клонируйте репозиторий</p>
                  <p className="text-white">git clone https://github.com/YOUR_USERNAME/telegram-admin-bot</p>
                  <p className="text-white">cd telegram-admin-bot</p>
                  <br />
                  <p># 2. Установите зависимости</p>
                  <p className="text-white">pip install -r requirements.txt</p>
                  <br />
                  <p># 3. Создайте .env файл</p>
                  <p className="text-white">echo "BOT_TOKEN=ваш_токен_от_botfather" {'>'} .env</p>
                  <br />
                  <p># 4. Запустите бота</p>
                  <p className="text-white">python admin_bot.py</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Deploy Tab */}
        {activeTab === 'deploy' && (
          <div className="space-y-8">
            {/* GitHub Steps */}
            <div className="bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <span className="text-2xl">📤</span> Шаг 1: Загрузка на GitHub
              </h2>
              <div className="grid md:grid-cols-3 gap-4">
                {githubSteps.map((s, i) => (
                  <div key={i} className="relative">
                    <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30 rounded-xl p-4">
                      <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold mb-3">
                        {s.step}
                      </div>
                      <h3 className="text-white font-semibold mb-1">{s.title}</h3>
                      <p className="text-white/60 text-sm">{s.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Hosting Platforms */}
            <div className="bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <span className="text-2xl">🌐</span> Шаг 2: Выберите хостинг (бесплатно!)
              </h2>
              
              {/* Platform Selector */}
              <div className="flex flex-wrap gap-3 mb-6">
                {deployOptions.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedPlatform(i)}
                    className={`px-4 py-3 rounded-xl font-medium transition-all flex items-center gap-2 ${
                      selectedPlatform === i
                        ? `bg-gradient-to-r ${opt.color} text-white shadow-lg`
                        : 'bg-white/5 text-white/70 hover:bg-white/10'
                    }`}
                  >
                    <span className="text-xl">{opt.icon}</span>
                    {opt.name}
                    {opt.free && (
                      <span className="text-xs bg-green-500/30 text-green-300 px-2 py-0.5 rounded-full">
                        FREE
                      </span>
                    )}
                  </button>
                ))}
              </div>

              {/* Selected Platform Details */}
              <div className={`bg-gradient-to-r ${deployOptions[selectedPlatform].color} rounded-2xl p-6`}>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-2xl font-bold text-white flex items-center gap-3">
                    <span className="text-3xl">{deployOptions[selectedPlatform].icon}</span>
                    {deployOptions[selectedPlatform].name}
                  </h3>
                  {deployOptions[selectedPlatform].link && (
                    <a 
                      href={deployOptions[selectedPlatform].link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2 bg-white/20 hover:bg-white/30 text-white rounded-lg transition"
                    >
                      Открыть сайт →
                    </a>
                  )}
                </div>
                <ol className="space-y-3">
                  {deployOptions[selectedPlatform].steps.map((step, i) => (
                    <li key={i} className="flex items-start gap-3 text-white/90">
                      <span className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center text-sm font-bold shrink-0">
                        {i + 1}
                      </span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>
            </div>

            {/* Important Note */}
            <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                <span>⚠️</span> Важно!
              </h3>
              <ul className="text-white/80 space-y-2">
                <li>• Telegram боты работают <strong className="text-yellow-300">постоянно 24/7</strong>, а не каждые 10 минут</li>
                <li>• Бот использует <strong className="text-yellow-300">long polling</strong> - он всегда слушает новые сообщения</li>
                <li>• Railway/Render/Fly.io предоставляют бесплатные часы работы (достаточно для бота)</li>
                <li>• Не забудьте добавить <code className="bg-black/30 px-2 py-0.5 rounded">BOT_TOKEN</code> в переменные окружения!</li>
              </ul>
            </div>
          </div>
        )}

        {/* Code Tab */}
        {activeTab === 'code' && (
          <div className="space-y-6">
            {/* File Structure */}
            <div className="bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <span>📁</span> Структура проекта
              </h2>
              <div className="bg-black/40 rounded-xl p-4 font-mono text-sm text-green-400">
                <pre>{`telegram-admin-bot/
├── admin_bot.py      # Основной код бота (600+ строк)
├── requirements.txt  # Зависимости Python
├── .env.example      # Пример конфигурации
├── .gitignore        # Игнорируемые файлы
├── Procfile          # Для Railway/Heroku
├── railway.json      # Конфиг Railway
├── render.yaml       # Конфиг Render
└── runtime.txt       # Версия Python`}</pre>
              </div>
            </div>

            {/* Download Links */}
            <div className="grid md:grid-cols-2 gap-4">
              {[
                { name: 'admin_bot.py', desc: 'Основной код бота', icon: '🐍' },
                { name: 'requirements.txt', desc: 'Зависимости', icon: '📦' },
                { name: 'railway.json', desc: 'Конфиг Railway', icon: '🚂' },
                { name: 'render.yaml', desc: 'Конфиг Render', icon: '🎨' },
                { name: 'Procfile', desc: 'Worker процесс', icon: '⚙️' },
                { name: '.gitignore', desc: 'Git игнор', icon: '🙈' },
              ].map((file, i) => (
                <a
                  key={i}
                  href={`/bot/${file.name}`}
                  download
                  className="flex items-center gap-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-4 transition group"
                >
                  <span className="text-2xl group-hover:scale-110 transition">{file.icon}</span>
                  <div className="flex-1">
                    <p className="text-white font-medium">{file.name}</p>
                    <p className="text-white/50 text-sm">{file.desc}</p>
                  </div>
                  <span className="text-purple-400">📥</span>
                </a>
              ))}
            </div>

            {/* Copy .env */}
            <div className="bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <span>🔑</span> Файл .env
                </h2>
                <button
                  onClick={() => copyToClipboard('BOT_TOKEN=ваш_токен_здесь\nLOG_CHANNEL_ID=')}
                  className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-sm rounded-lg transition"
                >
                  {copied ? '✓ Скопировано!' : '📋 Копировать'}
                </button>
              </div>
              <div className="bg-black/40 rounded-xl p-4 font-mono text-sm">
                <p className="text-gray-500"># Получите токен у @BotFather</p>
                <p className="text-yellow-400">BOT_TOKEN=<span className="text-white">ваш_токен_здесь</span></p>
                <br />
                <p className="text-gray-500"># ID канала для логов (опционально)</p>
                <p className="text-yellow-400">LOG_CHANNEL_ID=</p>
              </div>
            </div>

            {/* Commands Reference */}
            <div className="bg-white/5 backdrop-blur border border-white/10 rounded-2xl p-6">
              <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <span>📜</span> Все команды
              </h2>
              <div className="grid md:grid-cols-2 gap-4 text-sm">
                <div className="bg-black/30 rounded-xl p-4">
                  <h3 className="text-purple-400 font-bold mb-2">🔨 Модерация</h3>
                  <div className="space-y-1 text-white/80 font-mono">
                    <p>/ban [user] [причина]</p>
                    <p>/unban [user_id]</p>
                    <p>/kick [user] [причина]</p>
                    <p>/mute [время] [причина]</p>
                    <p>/unmute [user]</p>
                  </div>
                </div>
                <div className="bg-black/30 rounded-xl p-4">
                  <h3 className="text-yellow-400 font-bold mb-2">⚠️ Предупреждения</h3>
                  <div className="space-y-1 text-white/80 font-mono">
                    <p>/warn [user] [причина]</p>
                    <p>/unwarn [user]</p>
                    <p>/warns [user]</p>
                  </div>
                </div>
                <div className="bg-black/30 rounded-xl p-4">
                  <h3 className="text-red-400 font-bold mb-2">🗑 Сообщения</h3>
                  <div className="space-y-1 text-white/80 font-mono">
                    <p>/clear [количество]</p>
                    <p>/purge</p>
                    <p>/pin</p>
                    <p>/unpin</p>
                    <p>/unpin_all</p>
                  </div>
                </div>
                <div className="bg-black/30 rounded-xl p-4">
                  <h3 className="text-green-400 font-bold mb-2">🛡 Защита</h3>
                  <div className="space-y-1 text-white/80 font-mono">
                    <p>/antispam</p>
                    <p>/antiflood [лимит] [время]</p>
                    <p>/addword [слово]</p>
                    <p>/delword [слово]</p>
                    <p>/badwords</p>
                  </div>
                </div>
                <div className="bg-black/30 rounded-xl p-4">
                  <h3 className="text-cyan-400 font-bold mb-2">📊 Информация</h3>
                  <div className="space-y-1 text-white/80 font-mono">
                    <p>/stats</p>
                    <p>/chatinfo</p>
                    <p>/userinfo [user]</p>
                  </div>
                </div>
                <div className="bg-black/30 rounded-xl p-4">
                  <h3 className="text-pink-400 font-bold mb-2">⚙️ Настройки</h3>
                  <div className="space-y-1 text-white/80 font-mono">
                    <p>/welcome</p>
                    <p>/setwelcome [текст]</p>
                    <p>/slowmode [секунды]</p>
                    <p>/settings</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t border-white/10 mt-12 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-white/40">
          <p>🤖 Telegram Admin Bot • Python + Aiogram 3 • Бесплатный хостинг</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
